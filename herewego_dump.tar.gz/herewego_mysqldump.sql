-- phpMyAdmin SQL Dump
-- version 4.9.11
-- https://www.phpmyadmin.net/
--
-- Hôte : db5002087727.hosting-data.io
-- Généré le : Dim 02 mars 2025 à 22:07
-- Version du serveur : 5.7.42-log
-- Version de PHP : 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `herewego`
--
DROP DATABASE IF EXISTS `herewego`;
CREATE DATABASE IF NOT EXISTS `herewego` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `herewego`;

-- --------------------------------------------------------

--
-- Structure de la table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path_logo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=36 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `category`
--

INSERT INTO `category` (`id`, `name`, `color`, `path_logo`, `slug`) VALUES
(30, 'Concert', '#e3dc1c', 'https://via.placeholder.com/50', 'concert'),
(31, 'Art', '#cd2323', 'https://via.placeholder.com/50', 'art'),
(32, 'Sport', '#19e00b', 'https://via.placeholder.com/50', 'sport'),
(33, 'Culture', '#0d24ce', 'https://via.placeholder.com/50', 'culture'),
(34, 'Gastronomie', '#cf2a2a', 'https://via.placeholder.com/50', 'gastronomie'),
(35, 'Politique', '#d12929', '05cbb9fc01471c5cb4516dcad34d641e.jpg', 'politique');

-- --------------------------------------------------------

--
-- Structure de la table `city`
--

DROP TABLE IF EXISTS `city`;
CREATE TABLE IF NOT EXISTS `city` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `city_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_cp` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `doctrine_migration_versions`
--

DROP TABLE IF EXISTS `doctrine_migration_versions`;
CREATE TABLE IF NOT EXISTS `doctrine_migration_versions` (
  `version` varchar(191) COLLATE utf8_unicode_ci NOT NULL,
  `executed_at` datetime DEFAULT NULL,
  `execution_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Déchargement des données de la table `doctrine_migration_versions`
--

INSERT INTO `doctrine_migration_versions` (`version`, `executed_at`, `execution_time`) VALUES
('DoctrineMigrations\\Version20210220163409', '2021-03-27 18:44:25', 26),
('DoctrineMigrations\\Version20210221080052', '2021-03-27 18:44:25', 22),
('DoctrineMigrations\\Version20210221080644', '2021-03-27 18:44:25', 18),
('DoctrineMigrations\\Version20210221080805', '2021-03-27 18:44:25', 18),
('DoctrineMigrations\\Version20210221080952', '2021-03-27 18:44:25', 12),
('DoctrineMigrations\\Version20210221081315', '2021-03-27 18:44:25', 17),
('DoctrineMigrations\\Version20210221081608', '2021-03-27 18:44:25', 14),
('DoctrineMigrations\\Version20210221082319', '2021-03-27 18:44:25', 13),
('DoctrineMigrations\\Version20210221123209', '2021-03-27 18:44:25', 27),
('DoctrineMigrations\\Version20210221134518', '2021-03-27 18:44:25', 61),
('DoctrineMigrations\\Version20210221135226', '2021-03-27 18:44:25', 16),
('DoctrineMigrations\\Version20210221140854', '2021-03-27 18:44:25', 25),
('DoctrineMigrations\\Version20210221141752', '2021-03-27 18:44:25', 68),
('DoctrineMigrations\\Version20210221141904', '2021-03-27 18:44:25', 11),
('DoctrineMigrations\\Version20210221144828', '2021-03-27 18:44:25', 52),
('DoctrineMigrations\\Version20210221152904', '2021-03-27 18:44:25', 68),
('DoctrineMigrations\\Version20210221155511', '2021-03-27 18:44:25', 46),
('DoctrineMigrations\\Version20210221214745', '2021-03-27 18:44:25', 267),
('DoctrineMigrations\\Version20210223212301', '2021-03-27 18:44:26', 59),
('DoctrineMigrations\\Version20210223212825', '2021-03-27 18:44:26', 65),
('DoctrineMigrations\\Version20210223213407', '2021-03-27 18:44:26', 67),
('DoctrineMigrations\\Version20210223214154', '2021-03-27 18:44:26', 95),
('DoctrineMigrations\\Version20210224141823', '2021-03-27 18:44:26', 17),
('DoctrineMigrations\\Version20210224142820', '2021-03-27 18:44:26', 26),
('DoctrineMigrations\\Version20210225201040', '2021-03-27 18:44:26', 150),
('DoctrineMigrations\\Version20210228112416', '2021-03-27 18:44:26', 76),
('DoctrineMigrations\\Version20210228112912', '2021-03-27 18:44:26', 5),
('DoctrineMigrations\\Version20210303192130', '2021-03-27 18:44:26', 20),
('DoctrineMigrations\\Version20210303205718', '2021-03-27 18:44:26', 20),
('DoctrineMigrations\\Version20210303205840', '2021-03-27 18:44:26', 24),
('DoctrineMigrations\\Version20210306165202', '2021-03-27 18:44:26', 19),
('DoctrineMigrations\\Version20210307204308', '2021-03-27 18:44:26', 22),
('DoctrineMigrations\\Version20210307212202', '2021-03-27 18:44:26', 7),
('DoctrineMigrations\\Version20210311183221', '2021-03-27 18:44:26', 7),
('DoctrineMigrations\\Version20210311183424', '2021-03-27 18:44:26', 23),
('DoctrineMigrations\\Version20210328141959', '2021-03-28 16:21:47', 297);

-- --------------------------------------------------------

--
-- Structure de la table `event`
--

DROP TABLE IF EXISTS `event`;
CREATE TABLE IF NOT EXISTS `event` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `started_at` datetime NOT NULL,
  `ended_at` datetime NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `count_views` int(11) DEFAULT NULL,
  `tag` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` datetime NOT NULL,
  `slug` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `event_group_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `localisation_id` int(11) DEFAULT NULL,
  `facebook_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `instagram_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_link` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_3BAE0AA7B8B83097` (`event_group_id`),
  KEY `IDX_3BAE0AA712469DE2` (`category_id`),
  KEY `IDX_3BAE0AA7C68BE09C` (`localisation_id`),
  KEY `IDX_3BAE0AA7A76ED395` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `event`
--

INSERT INTO `event` (`id`, `title`, `description`, `started_at`, `ended_at`, `email`, `website`, `phone`, `count_views`, `tag`, `created_at`, `slug`, `event_group_id`, `category_id`, `localisation_id`, `facebook_link`, `instagram_link`, `twitter_link`, `user_id`) VALUES
(1, 'WoodKid au stade de France', '<p>Sed egestas elit nec justo aliquet aliquet. Curabitur quis posuere urna. Vivamus eleifend, turpis vitae pharetra molestie, velit eros iaculis urna, in sollicitudin elit risus et erat. Phasellus eu augue at ipsum molestie fringilla. Nunc nec arcu sodales, sagittis leo in, scelerisque mi. Sed porta porttitor erat, nec dapibus mauris pharetra tincidunt. Fusce tincidunt pharetra ultrices. In tempor euismod augue, id auctor nulla finibus sit amet. Etiam vitae fringilla sapien. Aenean luctus egestas malesuada. Nam consectetur, velit et varius tincidunt, lorem lectus commodo leo, vitae hendrerit orci tortor sed massa.</p>', '2021-05-03 18:30:00', '2021-05-05 21:30:00', 'woodkid@gmail.com', 'http://woodkid.fr', '06 71 75 78 79', 771, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'WOODKID SDF\' href=\'https://herewego.aureliengirard.fr/event/show/1\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>KZXIO-2171</div>               </a> </div>', '2021-03-27 21:14:09', 'woodkid-au-stade-de-france', NULL, 30, 4, 'http://facebook.com/woodkid', 'http://instagram.com/woodkid', 'http://twitter.com/woodkid', 1827),
(2, 'Concert de ACDC Olympia de Lille', '<p>Sed egestas elit nec justo aliquet aliquet. Curabitur quis posuere urna. Vivamus eleifend, turpis vitae pharetra molestie, velit eros iaculis urna, in sollicitudin elit risus et erat. Phasellus eu augue at ipsum molestie fringilla. Nunc nec arcu sodales, sagittis leo in, scelerisque mi. Sed porta porttitor erat, nec dapibus mauris pharetra tincidunt. Fusce tincidunt pharetra ultrices. In tempor euismod augue, id auctor nulla finibus sit amet. Etiam vitae fringilla sapien. Aenean luctus egestas malesuada. Nam consectetur, velit et varius tincidunt, lorem lectus commodo leo, vitae hendrerit orci tortor sed massa.</p>', '2021-06-15 12:20:00', '2021-06-15 21:30:00', 'event@acdc.com', 'http://acdc.com', '04 41 42 43 44', 865, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'concert acdc\' href=\'https://herewego.aureliengirard.fr/event/show/2\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>FTYIO-2159</div></a></div>', '2021-03-27 21:19:18', 'concert-de-acdc-olympia-de-lille', NULL, 30, 5, 'http://facebook.com/acdc', 'http://instagram.com/acdc', 'http://twitter.com/acdc', 1827),
(3, 'Soirée Violon Clermont-Ferrand', '<p>Sed egestas elit nec justo aliquet aliquet. Curabitur quis posuere urna. Vivamus eleifend, turpis vitae pharetra molestie, velit eros iaculis urna, in sollicitudin elit risus et erat. Phasellus eu augue at ipsum molestie fringilla. Nunc nec arcu sodales, sagittis leo in, scelerisque mi. Sed porta porttitor erat, nec dapibus mauris pharetra tincidunt. Fusce tincidunt pharetra ultrices. In tempor euismod augue, id auctor nulla finibus sit amet. Etiam vitae fringilla sapien. Aenean luctus egestas malesuada. Nam consectetur, velit et varius tincidunt, lorem lectus commodo leo, vitae hendrerit orci tortor sed massa.</p>', '2021-07-21 12:30:00', '2021-07-22 15:25:00', 'vionlon@gmail.com', 'http://tournelesviolons.fr', '07 77 77 77 77', 675, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'soiree violon\' href=\'https://herewego.aureliengirard.fr/event/show/3\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>SDRFT-2136</div></a></div>', '2021-03-27 21:27:30', 'soiree-violon-clermont-ferrand', NULL, 30, 6, 'http://facebook.fr/violon', 'http://instagram.fr/violon', 'http://twitter.fr/violon', 1827),
(4, 'Exposition picasso Nantes', '<p>Sed egestas elit nec justo aliquet aliquet. Curabitur quis posuere urna. Vivamus eleifend, turpis vitae pharetra molestie, velit eros iaculis urna, in sollicitudin elit risus et erat. Phasellus eu augue at ipsum molestie fringilla. Nunc nec arcu sodales, sagittis leo in, scelerisque mi. Sed porta porttitor erat, nec dapibus mauris pharetra tincidunt. Fusce tincidunt pharetra ultrices. In tempor euismod augue, id auctor nulla finibus sit amet. Etiam vitae fringilla sapien. Aenean luctus egestas malesuada. Nam consectetur, velit et varius tincidunt, lorem lectus commodo leo, vitae hendrerit orci tortor sed massa.</p>', '2021-05-06 08:30:00', '2021-05-10 21:30:00', 'picasso@gmail.com', 'http://picasso-event.fr', '02 02 22 54 65', 600, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'picasso\' href=\'https://herewego.aureliengirard.fr/event/show/4\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>CBRTN-2145</div></a></div>', '2021-03-27 21:34:14', 'exposition-picasso-nantes', NULL, 31, 10, 'http://facebook.fr/picasso', 'http://Instagram.fr/picasso', 'http://Twitter.fr/picasso', 1828),
(6, 'Salon du livre Nice', '<p>Sed egestas elit nec justo aliquet aliquet. Curabitur quis posuere urna. Vivamus eleifend, turpis vitae pharetra molestie, velit eros iaculis urna, in sollicitudin elit risus et erat. Phasellus eu augue at ipsum molestie fringilla. Nunc nec arcu sodales, sagittis leo in, scelerisque mi. Sed porta porttitor erat, nec dapibus mauris pharetra tincidunt. Fusce tincidunt pharetra ultrices. In tempor euismod augue, id auctor nulla finibus sit amet. Etiam vitae fringilla sapien. Aenean luctus egestas malesuada. Nam consectetur, velit et varius tincidunt, lorem lectus commodo leo, vitae hendrerit orci tortor sed massa.</p>', '2021-06-02 08:30:00', '2021-06-03 21:30:00', 'salon-livre@gmail.com', 'http://livre-salon.fr', '02 22 23 24 25', 608, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'salon livre\' href=\'https://herewego.aureliengirard.fr/event/show/6\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>JGASP-2183</div></a></div>', '2021-03-27 21:43:36', 'salon-du-livre-nice', NULL, 33, 9, 'http://facebook.fr/livre', 'http://instagram.fr/livre', 'http://twitter.fr/livre', 1828),
(7, 'Dégustation de saucisse de Strasbourg', '<p>Sed egestas elit nec justo aliquet aliquet. Curabitur quis posuere urna. Vivamus eleifend, turpis vitae pharetra molestie, velit eros iaculis urna, in sollicitudin elit risus et erat. Phasellus eu augue at ipsum molestie fringilla. Nunc nec arcu sodales, sagittis leo in, scelerisque mi. Sed porta porttitor erat, nec dapibus mauris pharetra tincidunt. Fusce tincidunt pharetra ultrices. In tempor euismod augue, id auctor nulla finibus sit amet. Etiam vitae fringilla sapien. Aenean luctus egestas malesuada. Nam consectetur, velit et varius tincidunt, lorem lectus commodo leo, vitae hendrerit orci tortor sed massa.</p>', '2021-08-15 08:12:00', '2021-08-17 21:30:00', 'saucisse@gmail.com', 'http://la-saucisse.fr', '05 45 46 47 48', 612, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'salon de la saucisse\' href=\'https://herewego.aureliengirard.fr/event/show/7\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>NEXOP-2126</div></a></div>', '2021-03-27 22:55:38', 'degustation-de-saucisse-de-strasbourg', NULL, 34, 11, 'http://facebook/saucisse', 'http://Instagram/saucisse', 'http://twitter/saucisse', 1831),
(8, 'Journée Gastronomie Americaine', '<p>Sed egestas elit nec justo aliquet aliquet. Curabitur quis posuere urna. Vivamus eleifend, turpis vitae pharetra molestie, velit eros iaculis urna, in sollicitudin elit risus et erat. Phasellus eu augue at ipsum molestie fringilla. Nunc nec arcu sodales, sagittis leo in, scelerisque mi. Sed porta porttitor erat, nec dapibus mauris pharetra tincidunt. Fusce tincidunt pharetra ultrices. In tempor euismod augue, id auctor nulla finibus sit amet. Etiam vitae fringilla sapien. Aenean luctus egestas malesuada. Nam consectetur, velit et varius tincidunt, lorem lectus commodo leo, vitae hendrerit orci tortor sed massa.</p>', '2021-09-25 08:45:00', '2021-09-26 01:00:00', 'la-gastro-us@gmail.com', 'http://la-gastro-us.com', '06 51 51 51 51', 494, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'concert acdc\' href=\'https://herewego.aureliengirard.fr/event/show/8\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>TRIOP-2151</div></a></div>', '2021-03-27 23:02:15', 'journee-gastronomie-americaine', NULL, 34, 12, 'http://facebook.fr/gatro-us', 'http://instagram.fr/gastro-us', 'http://twitter.fr/gastro-us', 1831),
(9, 'Randonnée pédestre dans le Verdon', '<p>Donec tristique mi vel enim vehicula, eu tristique nunc tempus. Phasellus euismod eros vel dui hendrerit, ut efficitur lorem hendrerit. Quisque porta auctor quam eu imperdiet. Duis a fringilla leo, nec auctor nisl. Proin enim arcu, facilisis ac felis vitae, dapibus consectetur lacus. In at condimentum erat. Morbi egestas elit id urna dictum, eu varius purus volutpat. Vestibulum dignissim neque id scelerisque viverra. Maecenas viverra erat ut accumsan blandit.</p>\r\n\r\n<p>Class aptent taciti sociosqu ad litora torquent</p>', '2021-07-12 06:30:00', '2021-07-14 23:30:00', 'rando@gmail.com', 'http://randonne.fr', '06 98 87 54 52', 498, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'sortie gorge verdon\' href=\'https://herewego.aureliengirard.fr/event/show/9\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>DFGT-2183</div></a></div>', '2021-03-27 23:10:04', 'randonnee-pedestre-dans-le-verdon', NULL, 32, 48, 'http://facebook.fr/rando', 'http://instagram.fr/rando', 'http://twitter.fr/rando', 1829),
(10, 'Grand prix Equestre de saint Cyr', '<p>Donec tristique mi vel enim vehicula, eu tristique nunc tempus. Phasellus euismod eros vel dui hendrerit, ut efficitur lorem hendrerit. Quisque porta auctor quam eu imperdiet. Duis a fringilla leo, nec auctor nisl. Proin enim arcu, facilisis ac felis vitae, dapibus consectetur lacus. In at condimentum erat. Morbi egestas elit id urna dictum, eu varius purus volutpat. Vestibulum dignissim neque id scelerisque viverra. Maecenas viverra erat ut accumsan blandit.</p>', '2021-05-22 11:45:00', '2021-05-28 18:18:00', 'equide@gmail.com', 'http://equitation.fr', '05 41 42 43 44', 535, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'gp saint cyr\' href=\'https://herewego.aureliengirard.fr/event/show/10\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>DPIOA-2171</div></a></div>', '2021-03-27 23:13:47', 'grand-prix-equestre-de-saint-cyr', NULL, 32, 14, 'http://facebook.fr/equide', 'http://instagram.fr/equide', 'http://twitter.fr/equide', 1829),
(11, 'Découverte Canoé', '<p>Donec tristique mi vel enim vehicula, eu tristique nunc tempus. Phasellus euismod eros vel dui hendrerit, ut efficitur lorem hendrerit. Quisque porta auctor quam eu imperdiet. Duis a fringilla leo, nec auctor nisl. Proin enim arcu, facilisis ac felis vitae, dapibus consectetur lacus. In at condimentum erat. Morbi egestas elit id urna dictum, eu varius purus volutpat. Vestibulum dignissim neque id scelerisque viverra. Maecenas viverra erat ut accumsan blandit.</p>\r\n\r\n<p>Class aptent taciti sociosqu ad litora torquent per</p>', '2021-04-25 12:30:00', '2021-04-28 16:54:00', 'canoe@gmail.com', 'http://canoe.fr', '07 78 79 74 75', 536, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'sortie canoe\' href=\'https://herewego.aureliengirard.fr/event/show/11\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>CANOE-2137</div></a></div>', '2021-03-27 23:23:54', 'decouverte-canoe', NULL, 32, 15, 'http://facebook.fr/canoe', 'http://instagram/canoe', 'http://twitter/canoe', 1829),
(12, 'Découverte des grottes de Lascaux', '<p>La grotte de Lascaux, situ&eacute;e sur la commune de Montignac-Lascaux, dans le d&eacute;partement fran&ccedil;ais de la Dordogne en r&eacute;gion Nouvelle-Aquitaine, dans la vall&eacute;e de la V&eacute;z&egrave;re, est l&#39;une des plus importantes grottes orn&eacute;es du Pal&eacute;olithique sup&eacute;rieur par le nombre et la qualit&eacute; esth&eacute;tique de ses &oelig;uvres</p>', '2021-04-05 12:30:00', '2021-05-05 18:45:00', 'grotte@gmail.com', 'http://grotte.com', '060666666', 537, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'grotte\' href=\'https://herewego.aureliengirard.fr/event/show/12\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>AORGT-2147</div></a></div>', '2021-03-28 17:01:42', 'decouverte-des-grottes-de-lascaux', NULL, 33, 28, 'http://facebook/grotte', 'http://instagram/grotte', 'http://twitter/grotte', 1827),
(13, 'Concourt Bowling', '<p>&nbsp;Ce jeu est ouvert &agrave; toute personne physique majeure &agrave; l&rsquo;exception des licenci&eacute;s, anciens licenci&eacute;s et du personnel du bowling.</p>\r\n\r\n<p>Les participants pourront tenter leur chance autant de fois qu&rsquo;ils le souhaitent.</p>\r\n\r\n<p>Le prix des parties sera en accord avec les tarifs en vigueur dans le bowling au moment de la r&eacute;alisation des parties.</p>\r\n\r\n<p>Les parties r&eacute;alis&eacute;es pendant le tournoi du lundi soir, la ligue du jeudi ne pourront pas &ecirc;tre prises en compte pour le concours.</p>\r\n\r\n<p>Les joueurs ne pourront pas utiliser de &laquo;&nbsp;bon pour une partie gratuite&nbsp;&raquo; pour participer au concours.</p>\r\n\r\n<p>Pour les joueurs r&eacute;alisant plus de deux parties cons&eacute;cutives ou jouant avec une formule &laquo;&nbsp;infini&nbsp;&raquo; ou &laquo;&nbsp;illimit&eacute;&nbsp;&raquo;, seules les deux premi&egrave;res parties seront prises en compte.</p>\r\n\r\n<p>La participation au jeu entra&icirc;ne l&rsquo;acceptation pure et simple du pr&eacute;sent r&egrave;glement.</p>\r\n\r\n<p>Article 3 : D&eacute;finition et valeur de la dotation</p>\r\n\r\n<p>&nbsp;Sont mises en jeu :</p>\r\n\r\n<p>Deux tablettes Samsung Galaxy Tab 2 10.1 16 GO d&rsquo;une valeur de 259 &euro; chacune (1 pour le meilleur homme et 1 pour la meilleure femme).</p>\r\n\r\n<p>La soci&eacute;t&eacute; organisatrice ne peut &ecirc;tre tenue responsable pour tous d&eacute;fauts ou d&eacute;faillances des dotations.</p>', '2021-12-05 12:23:00', '2021-12-06 18:30:00', 'bowling@gmail.com', 'http://bowling.com', '06 46 56 36 39', 535, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'bowling\' href=\'https://herewego.aureliengirard.fr/event/show/13\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>CRITO-2186</div></a></div>', '2021-03-28 17:59:21', 'concourt-bowling', NULL, 32, 39, NULL, 'http://instasgram/bowling', 'http://twitter/bowling', 1828),
(14, 'Présentation Herewego ISFAC', '<p><span style=\"font-family:Constantia,serif\">Le projet Fil-rouge&nbsp;Herewego est un projet de conception de site web permettant de mettre en relation les organisateurs d&rsquo;&eacute;v&egrave;nement et le public, centr&eacute; sur le partage de transport vers ces &eacute;v&eacute;nements. </span></p>\r\n\r\n<p><span style=\"font-family:Constantia,serif\">Le projet se fait en bin&ocirc;me et se d&eacute;roule sur 3 mois, au sein de la formation D&eacute;veloppeur Web de l&rsquo;ISFAC.</span></p>\r\n\r\n<p><span style=\"font-family:Constantia,serif\">Ce projet est l&rsquo;occasion pour les &eacute;tudiants de se mettre en confrontation face &agrave; la r&eacute;alisation d&rsquo;un projet complet, de la conception de la base de donn&eacute;es &agrave; la mise en ligne sur un h&eacute;bergement. Il est aussi l&rsquo;occasion de mettre en &oelig;uvre les connaissance pr&eacute;c&eacute;demment acquise tout en acqu&eacute;rant de nouvelles.</span></p>', '2021-03-30 08:30:00', '2021-03-30 17:30:00', 'isfac@gmail.com', 'http://isfac.fr', '06 71 75 78 79', 537, '<div style=\'border: 3px solid #054550; width: 120px;\'>\r\n                    <a style=\'text-decoration:none;color:black;\' title=\'isfac\' href=\'https://herewego.aureliengirard.fr/event/show/14\'>\r\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\r\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>TYUPO-2186</div></a></div>', '2021-03-29 10:26:48', 'presentation-herewego-isfac', NULL, 33, 33, 'https://facebook.com/isfac', 'https://instagram.com/isfac', 'https://twitter.com/isfac', 1828),
(15, 'Tournois de pétanque', '<p>Tu pointe ou tu tire</p>', '2021-03-25 12:30:00', '2021-04-07 14:30:00', 'petanque@gmail.com', 'http://petanque.com', '06 06060606', 537, '<div style=\'border: 3px solid #054550; width: 120px;\'>\n                    <a style=\'text-decoration:none;color:black;\' title=\'Tournois de pétanque\' href=\'https://herewego.aureliengirard.fr/event/show/15\'>\n                        <img style=\'width: 90%; margin: 0 auto;\' src=\'https://herewego.aureliengirard.fr/img/hwg_header.png\' alt=\'tag-event\'>\n                        <div style=\'text-align: center;font-weight: bold;color: #054550\'>H1RBC-2113</div>\n                    </a>\n                </div>', '2021-03-30 09:41:16', 'tournois-de-petanque', NULL, 32, 45, NULL, NULL, NULL, 1829);

-- --------------------------------------------------------

--
-- Structure de la table `event_group`
--

DROP TABLE IF EXISTS `event_group`;
CREATE TABLE IF NOT EXISTS `event_group` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `localisation`
--

DROP TABLE IF EXISTS `localisation`;
CREATE TABLE IF NOT EXISTS `localisation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `adress` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city_id` int(11) DEFAULT NULL,
  `city_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city_cp` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coordonnees_x` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coordonnees_y` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_BFD3CE8F8BAC62AF` (`city_id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `localisation`
--

INSERT INTO `localisation` (`id`, `adress`, `city_id`, `city_name`, `city_cp`, `coordonnees_x`, `coordonnees_y`) VALUES
(1, 'Rue de Poitiers', NULL, 'Vichy', '03200', '733260.03', '6559580.19'),
(2, 'Rue de Nantes', NULL, 'Rennes', '35000', '350976.95', '6787284.05'),
(3, 'Marseille 13e Arrondissement', NULL, 'Marseille 13e Arrondissement', '13013', '897047.18', '6252048.23'),
(4, 'Stade de France', NULL, 'Saint-Denis', '93200', '653181.74', '6869229'),
(5, 'Avenue Foch', NULL, 'Lille', '59800', '704048.51', '7059853.29'),
(6, 'Clermont-Ferrand', NULL, 'Clermont-Ferrand', '63100', '708264.82', '6520787.49'),
(7, 'Nantes', NULL, 'Nantes', '44100', '355581', '6692055.78'),
(8, 'Boulevard de l’Observatoire', NULL, 'Nice', '06300', '1046652.28', '6300819.11'),
(9, 'Boulevard de l’Observatoire', NULL, 'Nice', '06300', '1046652.28', '6300819.11'),
(10, 'Nantes', NULL, 'Nantes', '44100', '355581', '6692055.78'),
(11, 'Route de Schirmeck', NULL, 'Strasbourg', '67200', '1047261.71', '6840097.22'),
(12, 'Rue d’Abbeville', NULL, 'Amiens', '80000', '646643.57', '6979301.63'),
(13, 'Avenue du Petit Verdon', NULL, 'Fréjus', '83370', '1000903.32', '6259963.25'),
(14, 'Saint-Cyr', NULL, 'Saint-Cyr', '71240', '844436.33', '6621983'),
(15, 'À Gerse', NULL, 'Saint-Christophe-de-Double', '33230', '463309.01', '6446103.57'),
(16, '6 Place des Alisiers', NULL, 'Mignaloux-Beauvoir', '86550', '501962.28', '6607816.28'),
(17, 'Avenue de Nantes', NULL, 'Poitiers', '86000', '495599.81', '6613410.2'),
(18, 'Avenue de Nantes', NULL, 'Poitiers', '86000', '495599.81', '6613410.2'),
(19, '15 Rue Nationale', NULL, 'Lille', '59800', '704402.96', '7059973.68'),
(20, '56 Rue Pelleport', NULL, 'Bordeaux', '33800', '418641.55', '6420103.15'),
(21, '75 Avenue Thiers', NULL, 'Bordeaux', '33100', '419159.73', '6422288.89'),
(22, '15 Rue Pelleport', NULL, 'Bordeaux', '33800', '418759.25', '6420168.66'),
(23, '15 Rue Pelleport', NULL, 'Bordeaux', '33800', '418759.25', '6420168.66'),
(24, '6 Place des Capucins', NULL, 'Bordeaux', '33800', '418138.81', '6421007.32'),
(25, 'Monaco', NULL, 'Les Pennes-Mirabeau', '13170', '890036.02', '6257062.44'),
(26, 'La Rochelle', NULL, 'Saint-Nicolas-de-Redon', '44460', '321400.64', '6739215.37'),
(27, 'Avenue de Nantes', NULL, 'Poitiers', '86000', '495599.81', '6613410.2'),
(28, '6 Place des Capucins', NULL, 'Bordeaux', '33800', '418138.81', '6421007.32'),
(29, 'Monacos', NULL, 'Saverdun', '09700', '583987.53', '6239375.96'),
(30, '15 Rue Vestrepain', NULL, 'Toulouse', '31100', '571613.62', '6277533.29'),
(31, '15 Rue Vestrepain', NULL, 'Toulouse', '31100', '571613.62', '6277533.29'),
(32, 'Rue de la République', NULL, 'Poitiers', '86000', '496676.16', '6615918.43'),
(33, 'Rue de la République', NULL, 'Poitiers', '86000', '496676.16', '6615918.43'),
(34, '5 Rue Lecourbe', NULL, 'Paris', '75015', '649380.64', '6860745.5'),
(35, '5 Rue Lecourbe', NULL, 'Paris', '75015', '649380.64', '6860745.5'),
(36, '5 Rue Pasteur', NULL, 'Bordeaux', '33200', '415676.08', '6422721.33'),
(37, '5 Rue Pasteur', NULL, 'Bordeaux', '33200', '415676.08', '6422721.33'),
(38, 'Monacos', NULL, 'Saverdun', '09700', '583987.53', '6239375.96'),
(39, 'Monacos', NULL, 'Saverdun', '09700', '583987.53', '6239375.96'),
(40, 'Rue de Chatellerault', NULL, 'Châteauroux', '36000', '597997.36', '6634649.44'),
(41, 'Rue de Chatellerault', NULL, 'Châteauroux', '36000', '597997.36', '6634649.44'),
(42, '15 Rue Nationale', NULL, 'Lille', '59800', '704402.96', '7059973.68'),
(43, '15 Rue Nationale', NULL, 'Lille', '59800', '704402.96', '7059973.68'),
(44, 'Marseille 13e Arrondissement', NULL, 'Marseille 13e Arrondissement', '13013', '897047.18', '6252048.23'),
(45, 'Marseille 13e Arrondissement', NULL, 'Marseille 13e Arrondissement', '13013', '897047.18', '6252048.23'),
(46, '15 Rue Pelleport', NULL, 'Bordeaux', '33800', '418759.25', '6420168.66'),
(47, '15 Rue Pelleport', NULL, 'Bordeaux', '33800', '418759.25', '6420168.66'),
(48, 'Avenue du Petit Verdon', NULL, 'Fréjus', '83370', '1000903.32', '6259963.25');

-- --------------------------------------------------------

--
-- Structure de la table `participation`
--

DROP TABLE IF EXISTS `participation`;
CREATE TABLE IF NOT EXISTS `participation` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `added_at` datetime NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `event_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_AB55E24FA76ED395` (`user_id`),
  KEY `IDX_AB55E24F71F7E88B` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=56 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `participation`
--

INSERT INTO `participation` (`id`, `added_at`, `user_id`, `event_id`) VALUES
(1, '2021-03-27 23:44:02', 1848, 2),
(3, '2021-03-28 16:31:30', 1852, 1),
(4, '2021-03-28 16:34:17', 1852, 2),
(5, '2021-03-28 16:38:11', 1852, 4),
(7, '2021-03-28 16:39:44', 1852, 9),
(8, '2021-03-28 16:41:46', 1852, 6),
(11, '2021-03-28 16:52:09', 1851, 7),
(12, '2021-03-28 16:52:25', 1851, 1),
(27, '2021-03-28 17:08:33', 1850, 7),
(28, '2021-03-28 17:09:11', 1850, 1),
(29, '2021-03-28 17:09:28', 1850, 6),
(31, '2021-03-28 17:11:52', 1850, 9),
(32, '2021-03-28 17:12:07', 1850, 4),
(33, '2021-03-28 17:12:16', 1850, 2),
(34, '2021-03-28 17:17:19', 1850, 3),
(35, '2021-03-28 17:29:49', 1850, 10),
(36, '2021-03-28 17:53:12', 1850, 11),
(37, '2021-03-28 18:05:19', 1851, 10),
(38, '2021-03-28 18:09:48', 1849, 7),
(39, '2021-03-28 18:09:58', 1849, 6),
(40, '2021-03-28 18:12:03', 1851, 13),
(41, '2021-03-28 18:13:36', 1849, 1),
(42, '2021-03-28 18:13:42', 1849, 2),
(43, '2021-03-29 11:59:55', 1852, 10),
(44, '2021-03-29 12:03:28', 1852, 13),
(45, '2021-03-29 12:21:18', 1852, 3),
(47, '2021-03-29 14:29:47', 1849, 14),
(48, '2021-03-29 14:31:37', 1826, 14),
(50, '2021-03-29 15:55:58', 1826, 1),
(52, '2021-03-29 16:06:08', 1848, 11),
(53, '2021-03-29 16:23:11', 1851, 12),
(54, '2021-03-30 09:45:50', 1852, 11),
(55, '2021-03-30 09:46:17', 1852, 12);

-- --------------------------------------------------------

--
-- Structure de la table `picture`
--

DROP TABLE IF EXISTS `picture`;
CREATE TABLE IF NOT EXISTS `picture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `path` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `order_priority` int(11) NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_16DB4F8971F7E88B` (`event_id`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `picture`
--

INSERT INTO `picture` (`id`, `path`, `title`, `order_priority`, `event_id`) VALUES
(1, '8e385091e708e19812d4cd0005070bf4.jpg', 'WoodKid au stade de France', 1, 1),
(2, '6d82d07a9b4485662fe5e976f20bae45.jpg', 'WoodKid au stade de France', 1, 1),
(3, '69e80a22b228dbba20c500ee0b94e8ac.jpg', 'Concert de ACDC Olympia de Lille', 1, 2),
(4, '33c4c9dda0717fd1c92b6171d091a1e0.jpg', 'Concert de ACDC Olympia de Lille', 1, 2),
(5, '8fffe164e7dcfe5610695df450c8cd9b.jpg', 'Soirée Violon Clermont-Ferrand', 1, 3),
(6, 'd4c800b06b6147c79bcceedcba6d307b.jpg', 'Soirée Violon Clermont-Ferrand', 1, 3),
(7, '8fec5cf90bcdab75261b38f850d8689e.jpg', 'Exposition picasso Nantes', 1, 4),
(8, '9e3f36c44cdfca350b52ec63a2fd6394.jpg', 'Exposition picasso Nantes', 1, 4),
(9, 'a77c494603921949ced41856e353b635.jpg', 'Salon du livre Nice', 1, 6),
(10, '66a069af746dd23d41d4883abe779d4a.jpg', 'Salon du livre Nice', 1, 6),
(11, 'cf609f2616e8c25109339d08a2ec4a1b.jpg', 'Dégustation de saucisse de Strasbourg', 1, 7),
(12, '588b7cefc123f96613aabce96e83615d.jpg', 'Dégustation de saucisse de Strasbourg', 1, 7),
(13, 'fa0d014601bb5991c06e485f9d6d7b59.jpg', 'Journée Gastronomie Americaine', 1, 8),
(14, 'b635f70059b83a12da0c3b08edb33afe.jpg', 'Journée Gastronomie Americaine', 1, 8),
(15, '5db8fd3bdf61b24ca017346a2363f618.jpg', 'Randonnée pédestre dans le Verdon', 3, 9),
(17, '2a822d7d981bf33000cf0b27a589170f.jpg', 'Grand prix Equestre de saint Cyr', 1, 10),
(18, 'a1a82a67d5662baf369dcd9f9842eb0b.jpg', 'Grand prix Equestre de saint Cyr', 1, 10),
(19, '97092444409174d3195fd2dd76e9624c.jpg', 'Découverte Canoé', 1, 11),
(20, '89e0ae0ca54f1b99844fa3da94035c4e.jpg', 'Découverte Canoé', 1, 11),
(23, '64ebae46215c5e9e958182c961c17f24.jpg', 'Soirée Boolwing', 1, 13),
(24, '08026db8f709d42d0cb6dbb17fe5a60b.jpg', 'Découverte des grottes de Lascaux', 1, 12),
(25, '59e09dcc8958a88906b0b76c40e956c6.jpg', 'Découverte des grottes de Lascaux', 1, 12),
(26, 'e772d08c38bb221062ee964f27443c82.jpg', 'Concourt Bowling', 1, 13),
(27, '65d6853c5d905f906d638b51dfb21864.jpg', 'Concourt Bowling', 1, 13),
(28, 'e9d082105f8dbff84c00c14a77ed248b.jpg', 'Présentation Herewego ISFAC', 2, 14),
(29, 'ab9e3e07367f9e6d40f83a215dce445a.png', 'Présentation Herewego ISFAC', 1, 14),
(30, '94f89b6915d91b1826c9eb787432cd4a.jpg', 'Tournois de pétanque', 1, 15),
(31, 'f6a70348cc4a3449e99830c31bc2ef04.jpg', 'Randonnée pédestre dans le Verdon', 1, 9);

-- --------------------------------------------------------

--
-- Structure de la table `question_admin`
--

DROP TABLE IF EXISTS `question_admin`;
CREATE TABLE IF NOT EXISTS `question_admin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `answer` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `importance` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `question_admin`
--

INSERT INTO `question_admin` (`id`, `question`, `answer`, `importance`) VALUES
(1, '<p>Comment fonctionne l&rsquo;inscription sur le site ?</p>', '<p>Cliquez simplement sur <strong>&ldquo;inscription&rdquo;</strong> dans la barre de navigation.</p>\r\n\r\n<p>En fonction de votre r&ocirc;le, choisissez entre <strong>&ldquo;Cr&eacute;er un compte Utilisateur&rdquo;</strong> ou<strong> &ldquo;Cr&eacute;er un compte Organisateur&rdquo;</strong></p>\r\n\r\n<p>Entrez vos donn&eacute;es et validez.</p>\r\n\r\n<p>Tous les comptes sont valid&eacute;s par l&rsquo;administrateur du site HereWeGo. Attendez donc de recevoir un email de confirmation afin de pouvoir vous connecter sur le site.</p>', 1),
(2, '<p>Je souhaite participer &agrave; un &eacute;venement, comment je fais ?</p>', '<p>Si vous souhaitez participer &agrave; un &eacute;v&ecirc;nement, c&rsquo;est simple, il suffit d&rsquo;aller sur la <u>page d&rsquo;un evenement</u> et de cliquer sur <strong>&ldquo;Je participe&rdquo;</strong>.</p>\r\n\r\n<p>Vous pouvez ensuite annuler votre participation au m&ecirc;me endroit si vous le souhaitez.</p>', 1),
(3, '<p>Je veux proposer un transport pour un &eacute;v&ecirc;nement, comment &ccedil;a se passe ?</p>', '<p>Sur la <u>page d&rsquo;un &eacute;venement</u>, si vous y participez, vous pouvez cliquer sur <strong>&ldquo;Proposer un transport&rdquo;</strong>.</p>\r\n\r\n<p>Ensuite remplissez le <u>formulaire de cr&eacute;ation de transport</u> (<em>date et lieu de d&eacute;part, date et lieu d&rsquo;arriv&eacute;e, prix des places, nombre de places disponibles, commentaires</em>)</p>\r\n\r\n<p>Vous avez desormais acc&eacute;s &agrave; une <u>page de gestion de votre transport</u>.</p>\r\n\r\n<p>Vous pouvez y voir les demandes des utilisateurs voulant rejoindre votre transport.</p>\r\n\r\n<p>Vous pouvez les accepter ou non.</p>', 1),
(4, '<p>Je souhaite rejoindre un transport pour un &eacute;v&ecirc;nement. Comment je fais ?</p>', '<p>Sur la <u>page d&rsquo;un &eacute;v&ecirc;nement</u>, vous pouvez cliquer sur <strong>&ldquo;rejoindre un transport&rdquo;</strong>, cela vous donne acc&eacute;s &agrave; la liste des transports propos&eacute;s.</p>\r\n\r\n<p>En accedant &agrave; la <u>page du transport</u> qui vous convient pour pouvez faire une demande de ticket .</p>\r\n\r\n<p>Donnez&nbsp;le nombre de places que vous souhaitez, et un commentaire si besoin.</p>\r\n\r\n<p>Vous n&rsquo;avez plus qu&rsquo;&agrave; attendre la validation ou non de votre ticket par le manager du transport.</p>', 1),
(5, '<p>Je suis un utilisateur du site, comment j&rsquo;ai acc&eacute;s &agrave; mes informations ?</p>', '<p>Depuis votre <u>dashboard utilisateur</u> vous pouvez voir votre profil, le modifier ou m&ecirc;me modifier votre mot de passe.</p>\r\n\r\n<p>Vous avez aussi acc&eacute;s &agrave; l&rsquo;onglet <strong>&ldquo;Participations&rdquo;</strong>.</p>\r\n\r\n<p>Vous pouvez y voir tous les &eacute;v&ecirc;nements auquels vous participez, ainsi que votre status vis &agrave; vis de l&rsquo;&eacute;v&ecirc;nement (4 possibilit&eacute;s) :</p>\r\n\r\n<ol>\r\n	<li>\r\n	<p>Vous n&rsquo;avez pas de transport.&nbsp;</p>\r\n	</li>\r\n	<li>\r\n	<p>Vous avez fais une demande de transport.</p>\r\n	</li>\r\n	<li>\r\n	<p>Vous avez rejoint&nbsp;un transport,</p>\r\n	</li>\r\n	<li>\r\n	<p>Vous avez vous m&ecirc;me organis&eacute; un transport.</p>\r\n	</li>\r\n</ol>', 1),
(6, '<p>Je suis un organisateur d&rsquo;&eacute;v&ecirc;nement, comment je g&egrave;re mon profil et mes &eacute;v&ecirc;nements ?</p>', '<p>En tant qu&rsquo;organisateur, depuis <u>votre dashboard</u>&nbsp;vous pouvez cr&eacute;er un &eacute;v&ecirc;nement, et visualiser vos &eacute;v&ecirc;nement en cours, ainsi que ceux pass&eacute;s.</p>\r\n\r\n<p>Vous pouvez &eacute;galement t&eacute;l&eacute;charger au format CSV les informations de vos &eacute;v&ecirc;nements.</p>\r\n\r\n<p>Concernant votre profil, vous pouvez depuis la <u>page profil</u>, vous pouvez consulter vos informations, les&nbsp;modifier ou m&ecirc;me modifier votre mot de passe.</p>', 1),
(7, '<p>C&rsquo;est quoi le tag d&rsquo;un &eacute;v&ecirc;nement ?</p>', '<p>Chaque &eacute;v&ecirc;nement poss&egrave;de son propre tag / logo.&nbsp;</p>\r\n\r\n<p>C&rsquo;est un petit bout de code, que vous pouvez coller sur un autre site, et qui renverra vers la page de l&rsquo;&eacute;venement.</p>\r\n\r\n<p>Ce tag est accessible depuis la <u>page de l&rsquo;&eacute;v&ecirc;nement</u>.</p>', 1);

-- --------------------------------------------------------

--
-- Structure de la table `question_user`
--

DROP TABLE IF EXISTS `question_user`;
CREATE TABLE IF NOT EXISTS `question_user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `question` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D37D3BA6A76ED395` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Structure de la table `ticket`
--

DROP TABLE IF EXISTS `ticket`;
CREATE TABLE IF NOT EXISTS `ticket` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `asked_at` datetime NOT NULL,
  `count_places` int(11) NOT NULL,
  `commentary` longtext COLLATE utf8mb4_unicode_ci,
  `is_validate` tinyint(1) DEFAULT NULL,
  `validate_at` datetime DEFAULT NULL,
  `email_send_at` datetime DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `transport_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_97A0ADA3A76ED395` (`user_id`),
  KEY `IDX_97A0ADA39909C13F` (`transport_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `ticket`
--

INSERT INTO `ticket` (`id`, `asked_at`, `count_places`, `commentary`, `is_validate`, `validate_at`, `email_send_at`, `user_id`, `transport_id`) VALUES
(3, '2021-03-29 12:04:11', 2, '<p>J&#39;aimerais me joindre &agrave; vous :)</p>\r\n', NULL, NULL, NULL, 1852, 6),
(4, '2021-03-29 12:04:55', 1, '<p>/</p>\r\n', 1, '2021-03-29 12:05:53', NULL, 1852, 5),
(5, '2021-03-29 12:13:54', 2, '<p>besoin de 2 places. C&#39;est ok ?</p>\r\n', 0, '2021-03-29 12:16:53', NULL, 1850, 4),
(6, '2021-03-29 12:14:10', 1, '<p>Bonjour, je prendrai une place</p>\r\n', 0, '2021-03-29 12:16:56', NULL, 1849, 4),
(7, '2021-03-29 12:15:55', 3, '<p>&nbsp;/&nbsp;</p>\r\n', 1, '2021-03-30 09:52:21', NULL, 1851, 4),
(8, '2021-03-29 14:34:23', 1, '<p>j&#39;ai un concourt a passer</p>\r\n', 1, '2021-03-29 14:34:52', NULL, 1849, 7),
(9, '2021-03-30 09:47:32', 2, '<p>Je suis sympa !</p>\r\n', NULL, NULL, NULL, 1852, 8);

-- --------------------------------------------------------

--
-- Structure de la table `transport`
--

DROP TABLE IF EXISTS `transport`;
CREATE TABLE IF NOT EXISTS `transport` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `go_started_at` datetime NOT NULL,
  `go_ended_at` datetime NOT NULL,
  `return_started_at` datetime NOT NULL,
  `return_ended_at` datetime NOT NULL,
  `place_price` decimal(10,2) NOT NULL,
  `total_place` int(11) NOT NULL,
  `remaining_place` int(11) NOT NULL,
  `commentary` longtext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime NOT NULL,
  `event_id` int(11) DEFAULT NULL,
  `localisation_start_id` int(11) DEFAULT NULL,
  `localisation_return_id` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_66AB212E71F7E88B` (`event_id`),
  KEY `IDX_66AB212EEB8A9E18` (`localisation_start_id`),
  KEY `IDX_66AB212E564C7328` (`localisation_return_id`),
  KEY `IDX_66AB212EA76ED395` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `transport`
--

INSERT INTO `transport` (`id`, `go_started_at`, `go_ended_at`, `return_started_at`, `return_ended_at`, `place_price`, `total_place`, `remaining_place`, `commentary`, `created_at`, `event_id`, `localisation_start_id`, `localisation_return_id`, `user_id`) VALUES
(2, '2021-06-15 08:00:00', '2021-06-15 12:00:00', '2021-06-15 23:30:00', '2021-06-16 03:00:00', '10.00', 2, 2, 'Non fumeur', '2021-03-28 16:37:44', 2, 22, 23, 1852),
(3, '2021-03-30 19:06:00', '2021-04-04 19:06:00', '2021-04-30 19:06:00', '2021-05-01 19:06:00', '12.00', 2, 2, 'pas de chien merci.', '2021-03-28 19:07:05', 7, 26, 27, 1849),
(4, '2021-04-02 05:00:00', '2021-04-02 11:00:00', '2021-04-30 23:00:00', '2021-04-30 23:04:00', '15.00', 3, 0, 'test', '2021-03-28 20:01:10', 1, 30, 31, 1852),
(5, '2021-05-22 11:00:00', '2021-05-22 18:00:00', '2021-05-23 11:00:00', '2021-05-23 15:00:00', '12.00', 1, 0, ' /', '2021-03-29 11:55:07', 10, 34, 35, 1851),
(6, '2021-12-05 09:00:00', '2021-12-05 12:00:00', '2021-12-06 12:00:00', '2021-12-06 15:00:00', '13.00', 5, 5, 'Pas de gros bagages s\'il vous plait', '2021-03-29 11:59:04', 13, 36, 37, 1851),
(7, '2021-03-30 07:10:00', '2021-03-30 09:10:00', '2021-03-30 17:10:00', '2021-03-30 18:30:00', '1.00', 3, 2, 'pas de chien merci', '2021-03-29 14:33:12', 14, 40, 41, 1826),
(8, '2021-04-05 08:00:00', '2021-04-05 10:00:00', '2021-04-15 23:00:00', '2021-04-16 02:00:00', '12.00', 4, 4, 'Non fumeur.', '2021-03-29 16:25:42', 12, 42, 43, 1851),
(9, '2021-04-25 03:00:00', '2021-04-25 06:00:00', '2021-04-25 23:00:00', '2021-04-26 02:00:00', '15.00', 3, 3, 'non fumeur', '2021-03-30 09:51:18', 11, 46, 47, 1852);

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `email` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roles` json NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `lastname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `firstname` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `company_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `siret` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_validate` tinyint(1) DEFAULT NULL,
  `register_at` datetime NOT NULL,
  `validated_at` datetime DEFAULT NULL,
  `path_avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `web_site` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_premium` tinyint(1) NOT NULL DEFAULT '0',
  `localisation_id` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_8D93D649E7927C74` (`email`),
  KEY `IDX_8D93D649C68BE09C` (`localisation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=1853 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `email`, `roles`, `password`, `lastname`, `firstname`, `company_name`, `siret`, `phone`, `is_validate`, `register_at`, `validated_at`, `path_avatar`, `web_site`, `is_premium`, `localisation_id`) VALUES
(1825, 'admin@hwg.com', '[\"ROLE_ADMIN\"]', '$argon2id$v=19$m=65536,t=4,p=1$UWUyN3RRT1FnaXYuMWRqMw$idFAMAygQdlT/MO33VSf7Hpnlco9zKmQLQlXCu4IZZ8', 'Girard', 'Aurelien', 'herewego', NULL, '0836656565', 1, '2021-03-13 10:41:59', '2021-03-13 10:41:59', NULL, NULL, 1, NULL),
(1826, 'jeremy@evensy.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$Fwb2gN++9KCnBcdvXwbG4g$zwdOWjKpNbOdLqPKUiBQjiyn3u0rZtJwKspToSaHyv4', 'Dallain', 'Jeremy', NULL, NULL, '06 76 78 74 75', 1, '2021-03-27 20:59:08', NULL, '1', NULL, 0, 1),
(1827, 'sylvain@spectacle.fr', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Chanpignon', 'Sylvain', 'Spectacle français SARL', 'SRN000458963', '06 45 48 49 43', 1, '2021-03-27 21:01:03', NULL, '1', 'spectacle.fr', 0, 2),
(1828, 'luca@gmail.com', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$13BXka4ASar+WJSDEJulkg$cZEVTPz4EFtfN3tBpNO5cubpYTZG3p8dNj6Swhd4zbM', 'Di Melo', 'Luca', 'eola cyclisme', 'SRN012457896', '06 47 42 43 45', 1, '2021-03-27 21:05:28', NULL, '1', 'cyclisme-marseille.fr', 0, 3),
(1829, 'patrick@gmail.com', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Patrick', 'Depailler', 'SARL SPORT', 'SRNE00021', '+33 (0)4 27 77 91 36', 1, '2021-03-13 10:42:00', '2021-03-13 10:42:00', '1', NULL, 0, 1),
(1830, 'luce17@gmail.com', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$Fwb2gN++9KCnBcdvXwbG4g$zwdOWjKpNbOdLqPKUiBQjiyn3u0rZtJwKspToSaHyv4', 'Labbe', 'Luce', 'SAS EVENTS', 'SRNE00021', '0143539903', 0, '2021-03-13 10:42:00', '2021-03-13 10:42:00', '1', NULL, 0, 2),
(1831, 'alphonse64@gmail.com', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Fernande', 'Alphonse', 'Le Bouchet', 'SRNE00021', '0289906557', 1, '2021-03-13 10:42:00', '2021-03-13 10:42:00', '1', NULL, 0, 2),
(1832, 'joubert@gmail.com', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$Fwb2gN++9KCnBcdvXwbG4g$zwdOWjKpNbOdLqPKUiBQjiyn3u0rZtJwKspToSaHyv4', 'Joubert', 'Bernard', 'decouverte france', 'SRNE00021', '0947087009', 0, '2021-03-13 10:42:00', '2021-03-13 10:42:00', '1', NULL, 0, 3),
(1833, 'troy@gmail.com', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$Fwb2gN++9KCnBcdvXwbG4g$zwdOWjKpNbOdLqPKUiBQjiyn3u0rZtJwKspToSaHyv4', 'LeCheval', 'Troy', 'voyage de nos region', 'SRNE00021', '01 58 39 13 30', 0, '2021-03-13 10:42:00', '2021-03-13 10:42:00', '1', NULL, 0, 4),
(1834, 'lepottier@mgmail.com', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$Fwb2gN++9KCnBcdvXwbG4g$zwdOWjKpNbOdLqPKUiBQjiyn3u0rZtJwKspToSaHyv4', 'Le Pottier', 'Gilles', 'musee fr', 'SRNE00021', '+33 (0)1 49 59 56 49', 0, '2021-03-13 10:42:01', '2021-03-13 10:42:01', '1', NULL, 0, 5),
(1835, 'denis.denis@ifrance.com', '[\"ROLE_ORGANIZER\"]', '$argon2id$v=19$m=65536,t=4,p=1$Fwb2gN++9KCnBcdvXwbG4g$zwdOWjKpNbOdLqPKUiBQjiyn3u0rZtJwKspToSaHyv4', 'Denis', 'Petit', 'evenstsy', 'SRNE00021', '09 83 07 62 47', 1, '2021-03-13 10:42:01', '2021-03-13 10:42:01', '1', NULL, 0, 6),
(1836, 'thomas@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Droué', 'Thomas', NULL, NULL, NULL, 1, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 13),
(1837, 'cyril@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Nox', 'Cyril', NULL, NULL, NULL, 1, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 1),
(1838, 'delphine@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Blanc', 'Delphine', NULL, NULL, NULL, NULL, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 2),
(1839, 'magalie@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'thoux', 'Magalie', NULL, NULL, NULL, NULL, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 5),
(1840, 'victoria@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Silverstone', 'Victoria', NULL, NULL, NULL, NULL, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 8),
(1841, 'chloe@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Nissan', 'Cloe', NULL, NULL, NULL, NULL, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 1),
(1842, 'christophe@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Massue', 'Christophe', NULL, NULL, NULL, NULL, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 11),
(1843, 'mickael@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Girard', 'Mickael', NULL, NULL, NULL, NULL, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 11),
(1844, 'lilas@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Camille', 'Lilas', NULL, NULL, NULL, 1, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 6),
(1845, 'sofiane@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Drue', 'Sofiane', NULL, NULL, NULL, 1, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 6),
(1846, 'dupond@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Dupont', 'Georges', NULL, NULL, NULL, 1, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 3),
(1847, 'maxime@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'Possue', 'Maxime', NULL, NULL, NULL, 1, '2021-03-27 23:26:37', '2021-03-27 23:26:37', NULL, NULL, 0, 3),
(1848, 'vivien@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$x+MBFqXlTDfqhsX1XaKOZA$d0O2ar+mIANMybmTJ3TRHrqk/VgFJzd7uuEE1ZS6rxk', 'La Chambre', 'Vivien', NULL, NULL, NULL, 1, '2021-03-27 23:26:37', '2021-03-27 23:26:37', '1', NULL, 0, 3),
(1849, 'augirard17@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$KimuXMT06/rnx41Z2J8fww$mdpey0pRSHXo6mRPALPXTrqfPQIBry+7RJI/wtDN8SU', 'Girard', 'aurelien', NULL, NULL, '06 40 50 60 70', 1, '2021-03-28 14:58:00', NULL, '3', NULL, 0, 16),
(1850, 'jeanmichel@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$i3eqUHVlCXuO2s4hfSZE+Q$ffeWK8xeYTaz6FcyuaJRisBK/QRFEqn42F59+Si3q1g', 'Bodin', 'Jean Michel', NULL, NULL, '06 56 32 14 47', 1, '2021-03-28 16:02:40', NULL, '0', NULL, 0, 19),
(1851, 'bob@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$ZPJLHEsJsT4Ylnkt+uXfaA$rXbP0vTtN3O69txCAyqOvIbN5K4R+pvtJX1TZ57vxgI', 'Dylan', 'Bob', NULL, NULL, '03 23 23 25 54', 1, '2021-03-28 16:25:33', NULL, '4', NULL, 1, 20),
(1852, 'louise@gmail.com', '[\"ROLE_USER\"]', '$argon2id$v=19$m=65536,t=4,p=1$CUeJ8kjJfjaCYWGHilBQCg$7hDLXNLm75D9tyxk2juqb3ULX6tNPvc5jWVRu0y3BXs', 'Boutet', 'Louisa', NULL, NULL, '04 05 26 56 57', 1, '2021-03-28 16:26:42', NULL, '3', NULL, 0, 21);

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `event`
--
ALTER TABLE `event`
  ADD CONSTRAINT `FK_3BAE0AA712469DE2` FOREIGN KEY (`category_id`) REFERENCES `category` (`id`),
  ADD CONSTRAINT `FK_3BAE0AA7A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_3BAE0AA7B8B83097` FOREIGN KEY (`event_group_id`) REFERENCES `event_group` (`id`),
  ADD CONSTRAINT `FK_3BAE0AA7C68BE09C` FOREIGN KEY (`localisation_id`) REFERENCES `localisation` (`id`);

--
-- Contraintes pour la table `localisation`
--
ALTER TABLE `localisation`
  ADD CONSTRAINT `FK_BFD3CE8F8BAC62AF` FOREIGN KEY (`city_id`) REFERENCES `city` (`id`);

--
-- Contraintes pour la table `participation`
--
ALTER TABLE `participation`
  ADD CONSTRAINT `FK_AB55E24F71F7E88B` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  ADD CONSTRAINT `FK_AB55E24FA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Contraintes pour la table `picture`
--
ALTER TABLE `picture`
  ADD CONSTRAINT `FK_16DB4F8971F7E88B` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`);

--
-- Contraintes pour la table `question_user`
--
ALTER TABLE `question_user`
  ADD CONSTRAINT `FK_D37D3BA6A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Contraintes pour la table `ticket`
--
ALTER TABLE `ticket`
  ADD CONSTRAINT `FK_97A0ADA39909C13F` FOREIGN KEY (`transport_id`) REFERENCES `transport` (`id`),
  ADD CONSTRAINT `FK_97A0ADA3A76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);

--
-- Contraintes pour la table `transport`
--
ALTER TABLE `transport`
  ADD CONSTRAINT `FK_66AB212E564C7328` FOREIGN KEY (`localisation_return_id`) REFERENCES `localisation` (`id`),
  ADD CONSTRAINT `FK_66AB212E71F7E88B` FOREIGN KEY (`event_id`) REFERENCES `event` (`id`),
  ADD CONSTRAINT `FK_66AB212EA76ED395` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `FK_66AB212EEB8A9E18` FOREIGN KEY (`localisation_start_id`) REFERENCES `localisation` (`id`);

--
-- Contraintes pour la table `user`
--
ALTER TABLE `user`
  ADD CONSTRAINT `FK_8D93D649C68BE09C` FOREIGN KEY (`localisation_id`) REFERENCES `localisation` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
